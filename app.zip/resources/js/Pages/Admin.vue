<template>
    <section class="admin-landing">
        <h1>Panel de Administración</h1>
        <p>Bienvenido al panel de administración.</p>
        <!-- Agrega más secciones según tus necesidades aquí -->
    </section>
</template>

<script>
export default {
    name: "Admin",
    data() {
        return {};
    },
    methods: {}
};
</script>

<style scoped>
.admin-landing {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}
</style>